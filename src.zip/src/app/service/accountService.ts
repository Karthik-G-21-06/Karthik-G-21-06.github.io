import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  // This URL must match your Spring Boot @RequestMapping
  private apiUrl = 'http://localhost:8080/api/accounts';
  
  private http = inject(HttpClient);

  /**
   * Sends the form data to Spring Boot
   * @param accountData - The JSON object from your Angular form
   */
  createAccount(accountData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, accountData);
  }

  /**
   * Optional: Fetch all accounts to display in the list page
   */
  getAccounts(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }
  getAccountByNumber(accountNumber: string): Observable<any> {
  return this.http.get<any>(`${this.apiUrl}/${accountNumber}`);
  }
  deposit(data: any): Observable<any> {
  return this.http.post(`${this.apiUrl}/deposit`, data);
  }
}