import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from '../service/accountService';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-deposit',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private accountService = inject(AccountService);
  private router = inject(Router);

  account: any = null;
  showModal = false;
  transactionResult: any = null;

  depositForm = this.fb.group({
    amount: ['', [Validators.required, Validators.min(1)]],
    description: ['Deposit']
  });

  ngOnInit() {
    const accNo = this.route.snapshot.paramMap.get('id');
    if (accNo) {
      this.accountService.getAccountByNumber(accNo).subscribe(data => {
        this.account = data;
      });
    }
  }

  onDeposit() {
    if (this.depositForm.valid && this.account) {
      const payload = {
        accountNumber: this.account.accountNumber,
        amount: this.depositForm.value.amount,
        description: this.depositForm.value.description
      };

      this.accountService.deposit(payload).subscribe({
        next: (res) => {
          this.transactionResult = res;
          this.showModal = true;
        },
        error: (err) => alert('Deposit failed: ' + err.error.message)
      });
    }
  }

  closeModal() {
    this.router.navigate(['/accounts/details', this.account.accountNumber]);
  }
}