import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDeposit } from './account-deposit';

describe('AccountDeposit', () => {
  let component: AccountDeposit;
  let fixture: ComponentFixture<AccountDeposit>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccountDeposit]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountDeposit);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
