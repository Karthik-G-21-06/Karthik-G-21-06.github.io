import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Transaction } from '../models/transaction.model';

@Component({
  selector: 'app-transaction-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transaction-list.html',
  styleUrls: ['./transaction-list.css']
})
export class TransactionListComponent implements OnInit {
  transactions: Transaction[] = []; // Full list
  filteredTransactions: Transaction[] = []; // List for display/search
  searchTerm: string = '';

  ngOnInit(): void {
    // For now, load from localStorage to keep your current data
    const data = localStorage.getItem('bankTransactions');
    this.transactions = data ? JSON.parse(data) : [];
    this.filteredTransactions = [...this.transactions];
  }

  searchTransactions(): void {
    const term = this.searchTerm.toLowerCase().trim();
    if (!term) {
      this.filteredTransactions = [...this.transactions];
      return;
    }
    this.filteredTransactions = this.transactions.filter(t => 
      t.transactionId.toLowerCase().includes(term) ||
      t.customerName.toLowerCase().includes(term)
    );
  }

  resetSearch(): void {
    this.searchTerm = '';
    this.filteredTransactions = [...this.transactions];
  }

  deleteTransaction(id: string): void {
    if (confirm('Are you sure you want to delete this transaction?')) {
      this.transactions = this.transactions.filter(t => t.transactionId !== id);
      this.filteredTransactions = this.filteredTransactions.filter(t => t.transactionId !== id);
      localStorage.setItem('bankTransactions', JSON.stringify(this.transactions));
    }
  }
}