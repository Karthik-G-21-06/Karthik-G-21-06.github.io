import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Transaction } from '../models/transaction.model';

@Component({
  selector: 'app-transaction-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './transaction-detail.html',
  styleUrl: './transaction-detail.css'
})
export class TransactionDetailComponent implements OnInit {
  transaction: Transaction | undefined;
  errorState = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Get the ID from the route parameter
    const id = this.route.snapshot.paramMap.get('id');
    
    if (id) {
      const data = localStorage.getItem('bankTransactions');
      const transactions: Transaction[] = data ? JSON.parse(data) : [];
      this.transaction = transactions.find(t => t.transactionId === id);
      
      if (!this.transaction) {
        this.errorState = true;
      }
    } else {
      this.errorState = true;
    }
  }

  deleteTransaction(): void {
    if (this.transaction && confirm('Are you sure you want to delete this?')) {
      const data = localStorage.getItem('bankTransactions');
      let transactions: Transaction[] = data ? JSON.parse(data) : [];
      transactions = transactions.filter(t => t.transactionId !== this.transaction?.transactionId);
      localStorage.setItem('bankTransactions', JSON.stringify(transactions));
      this.router.navigate(['/list']);
    }
  }
}