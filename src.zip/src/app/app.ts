import { Component } from '@angular/core';
import { TransactionComponent } from './transaction/transaction.component';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TransactionComponent], // This lets you use <app-transaction> in app.html
  templateUrl: './app.html',
  styleUrl: './app.css'

})
export class AppComponent {
  title = 'frontend';
}