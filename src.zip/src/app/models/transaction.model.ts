export interface Transaction {
  transactionId: string;
  customerSSN: string;
  customerName: string;
  accountId: string;
  aadharNo: string;
  panNo: string;
  address: string;
  transactionDate: string;
  contactNumber: string;
  modeOfTransaction: string;
  transactionAmount: number;
  transactionType: string;
}