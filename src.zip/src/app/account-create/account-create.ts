import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AccountService } from '../service/accountService'; // You'll create this

@Component({
  selector: 'app-create-account',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {
  accountForm: FormGroup;
  showModal = false;
  createdAccountDetails: any = null;

  constructor(private fb: FormBuilder, private accountService: AccountService) {
    this.accountForm = this.fb.group({
      customerId: ['', Validators.required],
      accountType: ['', Validators.required],
      balance: [0, [Validators.required, Validators.min(0)]],
      currency: ['INR', Validators.required]
    });
  }

  onSubmit() {
    if (this.accountForm.valid) {
      // Send data to Spring Boot!
      this.accountService.createAccount(this.accountForm.value).subscribe({
        next: (response) => {
          this.createdAccountDetails = response;
          this.showModal = true; // Show that nice success modal
        },
        error: (err) => console.error('Backend error:', err)
      });
    }
  }
}