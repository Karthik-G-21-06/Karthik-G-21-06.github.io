import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { CommonModule } from '@angular/common'; // For *ngIf and pipes
import { ReactiveFormsModule } from '@angular/forms'; // For the form logic
import { TransactionService } from './transaction.service';


@Component({
  selector: 'app-transaction',
  standalone: true, // This confirms it's a standalone component
  imports: [CommonModule, ReactiveFormsModule], // Import tools here!
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})

export class TransactionComponent implements OnInit {
  transactionForm!: FormGroup;
  showModal = false;
  generatedId = '';
  transactionService: any;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.generatedId = 'TXN' + Date.now().toString().slice(-9);
    
    this.transactionForm = this.fb.group({
      transactionId: [{ value: this.generatedId, disabled: true }],
      customerSSN: ['', [Validators.required, Validators.maxLength(20)]],
      customerName: ['', [Validators.required, Validators.maxLength(100)]],
      accountId: ['', Validators.required],
      aadharNo: ['', [Validators.required, Validators.pattern('^[0-9]{12}$')]],
      panNo: ['', [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}$')]],
      address: ['', [Validators.required, Validators.maxLength(200)]],
      transactionDate: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      modeOfTransaction: ['', Validators.required],
      transactionAmount: ['', [Validators.required, Validators.min(0.01)]],
      transactionType: ['', Validators.required]
    });
  }

  onSubmit() {
  if (this.transactionForm.valid) {
    this.transactionService.addTransaction(this.transactionForm.value).subscribe({
      next: (response) => {
        console.log('Success!', response);
        this.transactionForm.reset(); // Clear form after success
      },
      error: (err) => {
        console.error('Check if Spring Boot is running!', err);
      }
    });
  }
}

  closeModal() {
    this.showModal = false;
    // Logic to redirect or reset form
  }
}