import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class TransactionService {
  private apiUrl = 'http://localhost:8080/api/transactions';
  private http = inject(HttpClient); // Modern way to inject

  // POST: Send data to Spring Boot
  addTransaction(transaction: any): Observable<any> {
    return this.http.post(this.apiUrl, transaction);
  }

  // GET: Fetch data from Spring Boot
  getTransactions(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }
}