import { Routes } from '@angular/router';
import { TransactionComponent } from './transaction/transaction.component';
import { TransactionListComponent } from './transaction-list/transaction-list';

export const routes: Routes = [
  { path: 'create', component: TransactionComponent },
  { path: 'list', component: TransactionListComponent },
  { path: '', redirectTo: 'list', pathMatch: 'full' } // Default page
];