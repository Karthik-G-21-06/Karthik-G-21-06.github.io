import { Routes } from '@angular/router';
import { TransactionComponent } from './transaction/transaction.component';
import { TransactionListComponent } from './transaction-list/transaction-list';
import { AccountListComponent } from './account-list/account-list';
import { CreateAccountComponent } from './account-create/account-create';
import { AccountDetailsComponent } from './account-detail/account-detail';

export const routes: Routes = [
  { path: 'create', component: TransactionComponent },
  { path: 'list', component: TransactionListComponent },
  { path: '', redirectTo: 'create', pathMatch: 'full' }, // Default page
  { path: 'accounts', component: AccountListComponent },
{ path: 'accounts/create', component: CreateAccountComponent },
{ path: 'accounts/details/:id', component: AccountDetailsComponent }
];