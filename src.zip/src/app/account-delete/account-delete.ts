import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AccountService } from '../service/accountService';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-account-delete',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './account-delete.component.html',
  styleUrls: ['./account-delete.component.css']
})
export class AccountDeleteComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private accountService = inject(AccountService);

  account: any = null;
  showModal = false;
  errorMessage = false;

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.accountService.getAccountByNumber(id).subscribe({
        next: (data) => this.account = data,
        error: () => this.errorMessage = true
      });
    }
  }

  openConfirmModal() { this.showModal = true; }
  closeModal() { this.showModal = false; }

  confirmDelete() {
    this.accountService.deleteAccount(this.account.accountNumber).subscribe({
      next: () => {
        this.closeModal();
        this.router.navigate(['/accounts']);
      },
      error: (err) => alert("Delete failed: " + err.message)
    });
  }
}