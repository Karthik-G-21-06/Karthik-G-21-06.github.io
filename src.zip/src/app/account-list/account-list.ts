import { Component, OnInit, inject } from '@angular/core';
import { AccountService } from '../service/accountService';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-account-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.css']
})
export class AccountListComponent implements OnInit {
  private accountService = inject(AccountService);
  
  accounts: any[] = [];
  filteredAccounts: any[] = [];
  searchTerm: string = '';
  loading: boolean = true;

  ngOnInit() {
    this.loadAccounts();
  }

  loadAccounts() {
    this.accountService.getAccounts().subscribe({
      next: (data) => {
        this.accounts = data;
        this.filteredAccounts = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching accounts', err);
        this.loading = false;
      }
    });
  }

  filterAccounts() {
    const term = this.searchTerm.toLowerCase();
    this.filteredAccounts = this.accounts.filter(acc => 
      acc.accountNumber.toLowerCase().includes(term) || 
      acc.customerId.toLowerCase().includes(term)
    );
  }
}