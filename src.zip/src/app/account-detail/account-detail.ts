import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AccountService } from '../service/accountService';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private accountService = inject(AccountService);
  
  account: any = null;
  loading = true;

  ngOnInit() {
    // 1. Get the account number from the URL
    const id = this.route.snapshot.paramMap.get('id');
    
    if (id) {
      // 2. Fetch from Spring Boot
      this.accountService.getAccountByNumber(id).subscribe({
        next: (data) => {
          this.account = data;
          this.loading = false;
        },
        error: (err) => {
          console.error('Account not found', err);
          this.loading = false;
        }
      });
    }
  }
}