package com.example.fincore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import com.example.fincore.repository.AccountRepository;
import com.example.fincore.model.Account;
import com.example.fincore.service.*;

@RestController
@RequestMapping("/api/accounts")
@CrossOrigin(origins = "http://localhost:4200")
public class AccountController {

    @Autowired
    private AccountRepository repository;

    @PostMapping
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        // Logic: Generate a secure Account Number
        String accNum = "ACC" + System.currentTimeMillis();
        account.setAccountNumber(accNum);
        account.setStatus("ACTIVE");
        
        Account savedAccount = repository.save(account);
        return ResponseEntity.ok(savedAccount);
    }
    @GetMapping("/{accountNumber}")
    public ResponseEntity<Account> getAccount(@PathVariable String accountNumber) {
        // Assuming you add 'findByAccountNumber' to your Repository
        return AccountRepository.findByAccountNumber(accountNumber)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @GetMapping
    public List<Account> getAllAccounts() {
        return AccountRepository.findAll();
    }
    
    @PostMapping("/deposit")
    public ResponseEntity<?> deposit(@RequestBody TransactionRequest request) {
        // We call a service method to handle the business logic
        TransactionRecord record = AccountService.performDeposit(
            request.getAccountNumber(), 
            request.getAmount(), 
            request.getDescription()
        );
        return ResponseEntity.ok(record);
    }
    @DeleteMapping("/{accountNumber}")
    public ResponseEntity<?> deleteAccount(@PathVariable String accountNumber) {
        AccountService.deleteAccount(accountNumber);
        return ResponseEntity.ok().build();
    }
}
