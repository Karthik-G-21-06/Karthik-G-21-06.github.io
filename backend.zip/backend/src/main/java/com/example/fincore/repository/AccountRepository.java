package com.example.fincore.repository;

import com.example.fincore.model.Account;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
    // You can add custom methods here later, like:
    // List<Account> findByCustomerId(String customerId);
	Optional<Account> findByAccountNumber(String accountNumber);
}