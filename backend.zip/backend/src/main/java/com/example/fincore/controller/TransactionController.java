package com.example.fincore.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import com.example.fincore.service.TransactionService;
import com.example.fincore.model.Transaction;

@RestController
@RequestMapping("/api/transactions")

@CrossOrigin(origins = "http://localhost:4200")
public class TransactionController {

    private final TransactionService service=null;

//    @PostMapping
//    public Transaction createTransaction(@RequestBody Transaction transaction) {
//        return service.saveTransaction(transaction);
//    }
//    @GetMapping("/test")
//    public String test() {
//        return "Backend is working!";
//    }

        @PostMapping
        public ResponseEntity<Transaction> receiveTransaction(@RequestBody Transaction transaction) {
            // This 'transaction' object now contains the data from your Angular form!
            System.out.println("Received description: " + transaction);
            
            // Save it to database or return it
            return ResponseEntity.ok(transaction);
        }
      
}
