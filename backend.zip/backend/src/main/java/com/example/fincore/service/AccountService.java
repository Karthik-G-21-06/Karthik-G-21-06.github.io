package com.example.fincore.service;

import com.example.fincore.model.Account;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.fincore.model.*;


@Transactional
public TransactionRecord performDeposit(String accNo, Double amount, String desc) {
    Account account = repository.findByAccountNumber(accNo)
        .orElseThrow(() -> new RuntimeException("Account not found"));

    // 1. Update Balance
    account.setBalance(account.getBalance() + amount);
    repository.save(account);

    // 2. Create Transaction History Record
    TransactionRecord tx = new TransactionRecord();
    tx.setAccountNumber(accNo);
    tx.setAmount(amount);
    tx.setType("DEPOSIT");
    tx.setDescription(desc);
    tx.setTimestamp(LocalDateTime.now());
    
    return transactionRepository.save(tx);
}
@Transactional
public void deleteAccount(String accountNumber) {
    Account account = accountRepository.findByAccountNumber(accountNumber)
        .orElseThrow(() -> new RuntimeException("Account not found"));
    
    // In a banking system, we usually check if balance is 0 before deleting
    if (account.getBalance() > 0) {
        throw new RuntimeException("Cannot delete account with remaining balance");
    }

    accountRepository.delete(account);
}