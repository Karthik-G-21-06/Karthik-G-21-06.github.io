package com.example.fincore.service;

import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import com.example.fincore.repository.TransactionRepository;
import com.example.fincore.model.Transaction;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepository repository=null;

    public Transaction saveTransaction(Transaction transaction) {
        return repository.save(transaction);
    }
}