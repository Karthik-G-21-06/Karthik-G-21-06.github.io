package com.example.fincore.model;

import java.time.LocalDate;
import lombok.Data;
import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name = "trxn")
public class Transaction {

    @Id
    private String transactionId;
    private String customerSSN;
    private String customerName;
    private String accountId;
    private String aadharNo;
    private String panNo;
    private String address;
    private LocalDate transactionDate;
    private String contactNumber;
    private String modeOfTransaction;
    private Double transactionAmount;
    private String transactionType;

    // Default Constructor (Required by JPA)
    public Transaction() {}

    // Getters and Setters
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public String getCustomerSSN() { return customerSSN; }
    public void setCustomerSSN(String customerSSN) { this.customerSSN = customerSSN; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getAccountId() { return accountId; }
    public void setAccountId(String accountId) { this.accountId = accountId; }

    public String getAadharNo() { return aadharNo; }
    public void setAadharNo(String aadharNo) { this.aadharNo = aadharNo; }

    public String getPanNo() { return panNo; }
    public void setPanNo(String panNo) { this.panNo = panNo; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public LocalDate getTransactionDate() { return transactionDate; }
    public void setTransactionDate(LocalDate transactionDate) { this.transactionDate = transactionDate; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String getModeOfTransaction() { return modeOfTransaction; }
    public void setModeOfTransaction(String modeOfTransaction) { this.modeOfTransaction = modeOfTransaction; }

    public Double getTransactionAmount() { return transactionAmount; }
    public void setTransactionAmount(Double transactionAmount) { this.transactionAmount = transactionAmount; }

    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }
}